# Calculadora de Aço
Uma calculadora web, que calcula o peso da chapa de aço > e transforma em valor R$